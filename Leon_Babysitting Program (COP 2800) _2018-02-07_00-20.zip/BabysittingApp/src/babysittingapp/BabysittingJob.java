
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
Create a BabysittingJob class for a babysitting service.  The class contains fields to hold the following:

A String that contains a job identification.  Job identifications are the year plus a number (starting at 1).  The first job identification will be 20171.  The next job identification will be 20172.

An int that represents the employee assigned to the job.  The code will always be 1, 2, or 3.

1 is for Cindy

2 is for Greg

3 is for Marcia

The number of children as an int that need to be watched.

The number of hours in the job (as an int).

The fee for the job.  Cindy is paid $8 per hour per child, Greg is paid $10 per hour for the first child and $4 per hour per additional child, Marcia is paid $12 per hour for the first child plus $5 extra per hour per child.

Calculate the total cost for the job (as an int).

Create a method that returns the total cost for the job (returnFee).
 */

/**
 *
 * @author dfreer
 */
public class BabysittingJob {
     int totalFee;
     int babySitterID;
      int numChildren;
      int numHours;
      String jobID,babySitterName;
//constructor
    public BabysittingJob(String jobID, int numChildren, int babySitterID, int numHours) {
      this.jobID=jobID;
      this.babySitterID=babySitterID;
      this.numChildren=numChildren;
      this.numHours=numHours;
      this.totalFee=totalFee;
     
    }
    
    public int returnFee(){
      
      /////////////////////////////////
        if(babySitterID==1){
         return numHours*8* numChildren;
        }
        
        //////////////////////////////
        else if(babySitterID==2){
            if(numChildren>1){
             return (10*numHours)+((numChildren-1)*4*numHours);
            }
            else {
                return 10*numHours;
            }
        }
        /////////////////////////////////////////////
        
        else if (babySitterID==3){
            if(numChildren>1){
            return (12*numHours)+(numChildren-1)*5*numHours;
        }
            else{
                return 12*numHours;
            }
           
        }
        else {
            return 0;
        }
    }
    
     @Override
    public String toString(){
        return jobID + " " + babySitterName + " " + totalFee;
    }
    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        BabysittingJob first = new BabysittingJob(s.next(), s.nextInt(), s.nextInt() ,s.nextInt()); 
        System.out.println(first.returnFee()); 
        BabysittingJob second = new BabysittingJob(s.next(), s.nextInt(), s.nextInt() ,s.nextInt());
        System.out.println(second.returnFee());  
        BabysittingJob third = new BabysittingJob(s.next(), s.nextInt(), s.nextInt() ,s.nextInt());
        System.out.println(third.returnFee()); 
        
    }
}
